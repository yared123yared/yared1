//package sample;
//
//import javafx.application.Application;
//import javafx.fxml.FXMLLoader;
//import javafx.scene.Parent;
//import javafx.scene.Scene;
//import javafx.stage.Stage;
//
//public class main_sock extends Application {
//    public void start(Stage primaryStage) throws Exception {
//        Main c=new Main();
//        Parent root = FXMLLoader.load(getClass().getResource("HOME.fxml"));
//        primaryStage.setTitle("Hello World");
//        //primaryStage.setScene(new Scene(root, 300, 275));
//        Scene scene1 = new Scene(root, 800, 500);
//        scene1.getStylesheets().add(getClass().getResource("new.css").toExternalForm());
//        primaryStage.setScene(scene1);
//        primaryStage.show();
//
//    }
//
//    //@Override
//    public void run() {
//        new main_sock();
//    }
//}
