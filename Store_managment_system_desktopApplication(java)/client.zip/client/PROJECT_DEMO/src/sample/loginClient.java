package sample;

public abstract class loginClient {
    public abstract void login();
}
