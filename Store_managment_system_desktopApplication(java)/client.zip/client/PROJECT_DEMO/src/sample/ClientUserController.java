package sample;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;

public class ClientUserController {
    @FXML
    public void item(ActionEvent event){}
    @FXML
    public void complain(ActionEvent event){}
    @FXML
    public void get_notification(ActionEvent event){}

}
