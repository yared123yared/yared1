package sample;

import java.awt.event.ActionEvent;
import java.sql.SQLException;

public abstract class client {


    public abstract void add(String strin) throws SQLException, ClassNotFoundException;
}
