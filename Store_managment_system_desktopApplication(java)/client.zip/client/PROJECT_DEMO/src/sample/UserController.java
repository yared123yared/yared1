package sample;

public class UserController  extends loginClient{
    @Override
    public void login() {

    }
}
