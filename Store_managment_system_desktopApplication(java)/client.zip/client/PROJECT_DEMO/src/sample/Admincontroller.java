package sample;

public class Admincontroller extends loginClient {
    @Override
    public void login() {

    }
}
