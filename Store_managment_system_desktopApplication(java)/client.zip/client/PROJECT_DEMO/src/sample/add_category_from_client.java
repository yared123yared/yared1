package sample;

import java.awt.event.ActionEvent;
import java.sql.SQLException;

public class add_category_from_client extends client {

    public void add() {

    }



    @Override
    public void add(String strin) {

    }
}
