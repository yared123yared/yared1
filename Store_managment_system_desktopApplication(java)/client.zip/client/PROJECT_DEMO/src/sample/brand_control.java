package sample;

public class brand_control {

}
