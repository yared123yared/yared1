package sample;

import java.util.ArrayList;

public interface collection_2 {
    ArrayList<String>category_collection=new ArrayList<>();
    ArrayList<String>roll=new ArrayList<>();
    ArrayList<stock_user> stocks = new ArrayList<>();
    ArrayList<stock_user> updateStocks = new ArrayList<>();
    ArrayList<complain_sheet_user > complain_sheet_users= new ArrayList<>();
    ArrayList<complain_sheet_user > complain_sheet_users_list= new ArrayList<>();
    ArrayList<category_class > catagory_sheet= new ArrayList<>();
    ArrayList<category_class> catagory_sheet_selection= new ArrayList<>();
    ArrayList<requested_user> request_items= new ArrayList<>();
    ArrayList<requested_user> request_selItem= new ArrayList<>();
    ArrayList<String>u_name=new ArrayList<>();
    ArrayList<String>item_id_collection=new ArrayList<>();


}
