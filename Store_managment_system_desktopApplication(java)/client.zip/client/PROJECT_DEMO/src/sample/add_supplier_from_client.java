package sample;

public class add_supplier_from_client extends client {



    @Override
    public void add(String strin) {

    }
}
