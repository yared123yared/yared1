package sample;

public class add_product_from_client extends client {




    @Override
    public void add(String strin) {

    }
}
