package sample;

import javafx.fxml.FXML;

import java.awt.event.ActionEvent;

public class complain {
    @FXML
    public  void submit_complain(ActionEvent event){



    }
}
