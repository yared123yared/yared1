package repository

import (
	"errors"

	"github.com/jinzhu/gorm"

	"github.com/web1_group_project/hospital_server/Admin"
	"github.com/web1_group_project/hospital_server/entity"
)

// ManageProfileRepository implements Admin.ManageProfileRepository interface
type MockUserRepository struct {
	conn *gorm.DB
}

// ManageProfileRepository returns new object of ManageProfileRepository
func NewMockUserRepository(db *gorm.DB) Admin.UserRepository {
	return &MockUserRepository{conn: db}
}

// Doctors return all doctors stored in the databasee
func (userRepo *MockUserRepository) Users() ([]entity.User, []error) {
	prfs := []entity.User{entity.ProfileMock}

	return prfs, nil
}

// Doctor retrieves a doctor from the database by its id
func (userRepo *MockUserRepository) User(id uint) (*entity.User, []error) {
	prfs := entity.ProfileMock
	if id == 1 {
		return &prfs, nil
	}
	return nil, []error{errors.New("Not Found")}
}

// UpdateDoctor updats a given doctor in the database
func (userRepo *MockUserRepository) UpdateUser(user *entity.User) (*entity.User, []error) {
	prf := entity.ProfileMock

	return &prf, nil
}

// DeleteDoctor deletes a given doctor from the database
func (userRepo *MockUserRepository) DeleteUser(id uint) (*entity.User, []error) {
	prf := entity.ProfileMock
	return &prf, nil
}

// StoreDoctor stores a given doctor in the database
func (userRepo *MockUserRepository) StoreUser(user *entity.User) (*entity.User, []error) {
	prf := entity.ProfileMock

	return &prf, nil
}

// PhoneExists check if a given phone number is found
func (userRepo *MockUserRepository) PhoneExists(phone string) bool {
	return true
}

// EmailExists check if a given email is found
func (userRepo *MockUserRepository) EmailExists(email string) bool {

	return true
}

// UserRoles returns list of application roles that a given user has
func (userRepo *MockUserRepository) UserRoles(user *entity.User) ([]entity.Role, []error) {

	userRoles := []entity.Role{}

	return userRoles, nil
}

// UserByEmail retrieves a user by its email address from the database
func (userRepo *MockUserRepository) UserByEmail(email string) (*entity.User, []error) {
	user := entity.ProfileMock

	return &user, nil
}
