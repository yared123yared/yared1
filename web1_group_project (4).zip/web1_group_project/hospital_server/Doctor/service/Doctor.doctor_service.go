package service

import (
	//"github.com/yaredsolomon/webProgram1/hospital/entity"
	//"github.com/yaredsolomon/webProgram1/hospital/request"
	//"github.com/yaredsolomon/webProgram1/hospital/request"

	"github.com/web1_group_project/hospital_server/Doctor"
	"github.com/web1_group_project/hospital_server/entity"
)

// AppointmentService implements request.AppointmentService interface
type AppointmentService struct {
	appointRepo Doctor.AppointmentRepository
}

// NewAppointmentService  returns a new AppointmentService object
func NewAppointmentService(appointmentRepository Doctor.AppointmentRepository) Doctor.AppointmentService {
	return &AppointmentService{appointRepo: appointmentRepository}
}

// Appointments returns all stored application Appointments
func (as *AppointmentService) Appointments() ([]entity.Doctor, []error) {
	appointments, errs := as.appointRepo.Appointments()
	if len(errs) > 0 {
		return nil, errs
	}
	return appointments, errs
}

// Appointment retrieves an application Appointment by its id
func (as *AppointmentService) Appointment(id uint) (*entity.Doctor, []error) {
	apt, errs := as.appointRepo.Appointment(id)
	if len(errs) > 0 {
		return nil, errs
	}
	return apt, errs
}
func (as *AppointmentService) AppAppointment(id uint) (*entity.Appointment, []error) {
	apt, errs := as.appointRepo.AppAppointment(id)
	if len(errs) > 0 {
		return nil, errs
	}
	return apt, errs
}
func (as *AppointmentService) Prescribtion(id uint) (*entity.Prescription, []error) {

	apt, errs := as.appointRepo.Prescribtion(id)
	if len(errs) > 0 {
		return nil, errs
	}
	return apt, errs
}
func (as *AppointmentService) CheckUp(id uint) (*entity.Diagnosis, []error) {

	apt, errs := as.appointRepo.CheckUp(id)
	if len(errs) > 0 {
		return nil, errs
	}
	return apt, errs
}

// UpdateAppointment updates  a given application appointment
func (as *AppointmentService) UpdateAppointment(appointment *entity.Doctor) (*entity.Doctor, []error) {
	apt, errs := as.appointRepo.UpdateAppointment(appointment)
	if len(errs) > 0 {
		return nil, errs
	}
	return apt, errs
}
func (as *AppointmentService) AppUpdateAppointment(appointment *entity.Appointment) (*entity.Appointment, []error) {
	apt, errs := as.appointRepo.AppUpdateAppointment(appointment)
	if len(errs) > 0 {
		return nil, errs
	}
	return apt, errs
}
func (as *AppointmentService) UpdatePrescription(prescription *entity.Prescription) (*entity.Prescription, []error) {

	apt, errs := as.appointRepo.UpdatePrescription(prescription)
	if len(errs) > 0 {
		return nil, errs
	}
	return apt, errs
}
func (as *AppointmentService) UpdateCheckUp(diagonosis *entity.Diagnosis) (*entity.Diagnosis, []error) {

	apt, errs := as.appointRepo.UpdateCheckUp(diagonosis)
	if len(errs) > 0 {
		return nil, errs
	}
	return apt, errs
}

// DeleteAppointment deletes a given application appointment
func (as *AppointmentService) DeleteAppointment(id uint) (*entity.Appointment, []error) {
	apt, errs := as.appointRepo.DeleteAppointment(id)
	if len(errs) > 0 {
		return nil, errs
	}
	return apt, errs
}
func (as *AppointmentService) DeletePrescription(id uint) (*entity.Prescription, []error) {
	apt, errs := as.appointRepo.DeletePrescription(id)
	if len(errs) > 0 {
		return nil, errs
	}
	return apt, errs
}
