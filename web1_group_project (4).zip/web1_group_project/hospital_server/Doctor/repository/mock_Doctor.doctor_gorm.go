package repository

import (
	"errors"
	"fmt"

	"github.com/jinzhu/gorm"
	//"github.com/yaredsolomon/webProgram1/hospital/request"

	"github.com/web1_group_project/hospital_server/Doctor"
	"github.com/web1_group_project/hospital_server/entity"
)

// AppointmentGormRepo Implements the request.AppointmentRepository interface
type MockAppointmentGormRepo struct {
	conn *gorm.DB
}

// NewAppointmentGormRepo creates a new object of AppointmentGormRepo
func NewMockAppointmentGormRepo(db *gorm.DB) Doctor.AppointmentRepository {
	return &MockAppointmentGormRepo{conn: db}
}

// Appointments return all Appointments from the database
func (appointRepo *MockAppointmentGormRepo) Appointments() ([]entity.Doctor, []error) {
	appointments := []entity.Doctor{entity.DoctorMock}
	return appointments, nil
}

// Appointment retrieves a Appointment by its id from the database
func (appointRepo *MockAppointmentGormRepo) Appointment(id uint) (*entity.Doctor, []error) {
	appointment := entity.Doctor{}
	if id == 1 {
		return &appointment, nil
	}
	return nil, []error{errors.New("Not found")}
}

// UpdateAppointment updates a given Appointment in the database
func (appointRepo *MockAppointmentGormRepo) UpdateAppointment(appointment *entity.Doctor) (*entity.Doctor, []error) {
	prec := entity.DoctorMock
	return &prec, nil
}

// DeleteAppointment deletes a given appointment from the database
func (appointRepo *MockAppointmentGormRepo) DeleteAppointment(id uint) (*entity.Appointment, []error) {
	prec := entity.AppointmentMock
	return &prec, nil
}
func (appointRepo *MockAppointmentGormRepo) DeletePrescription(id uint) (*entity.Prescription, []error) {
	prec := entity.PrescriptionMock
	return &prec, nil
}

func (appointRepo *MockAppointmentGormRepo) AppAppointment(id uint) (*entity.Appointment, []error) {
	fmt.Println("only appointment")
	appointment := entity.Appointment{}
	errs := appointRepo.conn.First(&appointment, "id=?", id).GetErrors()
	if len(errs) > 0 {
		return nil, errs
	}
	return &appointment, errs
}
func (appointRepo *MockAppointmentGormRepo) AppUpdateAppointment(appointment *entity.Appointment) (*entity.Appointment, []error) {
	fmt.Println("i am at the update method")
	apt := appointment
	fmt.Println("thise is the data that will be updated")
	fmt.Println(apt)

	errs := appointRepo.conn.Save(apt).GetErrors()
	if len(errs) > 0 {
		return nil, errs
	}
	fmt.Println("i have done witht the updates")
	return apt, errs
}
func (appointRepo *MockAppointmentGormRepo) Prescribtion(id uint) (*entity.Prescription, []error) {
	fmt.Println("thise is the appointment method")
	prescribtion := entity.Prescription{}
	errs := appointRepo.conn.First(&prescribtion, "id=?", id).GetErrors()
	if len(errs) > 0 {
		return nil, errs
	}
	return &prescribtion, errs
}
func (appointRepo *MockAppointmentGormRepo) CheckUp(id uint) (*entity.Diagnosis, []error) {
	fmt.Println("thise is the appointment method")
	prescribtion := entity.Diagnosis{}
	errs := appointRepo.conn.First(&prescribtion, "id=?", id).GetErrors()
	if len(errs) > 0 {
		return nil, errs
	}
	return &prescribtion, errs
}

func (appointRepo *MockAppointmentGormRepo) UpdatePrescription(prescribtion *entity.Prescription) (*entity.Prescription, []error) {
	fmt.Println("i am at the update method")
	apt := prescribtion
	fmt.Println("thise is the data that will be updated")
	fmt.Println(apt)

	errs := appointRepo.conn.Save(apt).GetErrors()
	if len(errs) > 0 {
		return nil, errs
	}
	fmt.Println("i have done witht the updates")
	return apt, errs
}
func (appointRepo *MockAppointmentGormRepo) UpdateCheckUp(prescribtion *entity.Diagnosis) (*entity.Diagnosis, []error) {
	fmt.Println("i am at the update method")
	apt := prescribtion
	fmt.Println("thise is the data that will be updated")
	fmt.Println(apt)

	errs := appointRepo.conn.Save(apt).GetErrors()
	if len(errs) > 0 {
		return nil, errs
	}
	fmt.Println("i have done witht the updates")
	return apt, errs
}
