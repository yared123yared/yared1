package laboratorist_handler

import (
	"fmt"
	"html/template"
	"log"
	"net/http"
	"strconv"
	"time"

	//"github.com/fasikawkn/web1_group_project/hospital_server/session"
	laborData "github.com/web1_group_project/hospital_client/data/laboratorist"
	"github.com/web1_group_project/hospital_client/delivery/http/handler"
	"github.com/web1_group_project/hospital_client/entity"
	"github.com/web1_group_project/hospital_client/rtoken"
)

//var sesion uint = session.GetLaborSession()

// LaborProfHandler handles category handler admin requests
type LaborProfHandler struct {
	tmpl              *template.Template
	UserHandler       *handler.UserHandler
	LogedInPharmacist *entity.Pharmacist
	csrfSignKey       []byte
}

// NewAdminCategoryHandler initializes and returns new AdminCateogryHandler
func NewLaborTempHandler(T *template.Template, userHandler *handler.UserHandler, csKey []byte) *LaborProfHandler {
	return &LaborProfHandler{
		tmpl:        T,
		UserHandler: userHandler,
		csrfSignKey: csKey}
}
func (ach *LaborProfHandler) LaborDashHandler(w http.ResponseWriter, r *http.Request) {
	// fmt.Println("Dashboard")
	// num := laborData.GetDiagsNumber(1)
	// num2 := laborData.GetPrescsNumber(1)
	// var num3 int = num / 12
	// var num4 int = num2 / 12
	// dash := entity.Dash{

	// 	Annual_one:  num,
	// 	Monthly_one: num3,
	// 	Annual_two:  num2,
	// 	Monthly_two: num4,
	// }

	ach.tmpl.ExecuteTemplate(w, "labor.home.layout", nil)
}

func (ach *LaborProfHandler) LaborDiagnosisHandler(w http.ResponseWriter, r *http.Request) {
	diagnosiss, _ := laborData.GetDiagnosiss()
	log.Println("labor handelr diagnosis")
	ach.tmpl.ExecuteTemplate(w, "labor.diag.home.layout", diagnosiss)
}

func (ach *LaborProfHandler) LaborProfileHandler(w http.ResponseWriter, r *http.Request) {
	log.Println("labor handelr profile")
	labratorist, _ := laborData.GetLaboratorist(ach.UserHandler.LoggedInUser.ID)
	ach.tmpl.ExecuteTemplate(w, "labor.prof.layout", labratorist)
}

func (ach *LaborProfHandler) LaborProfileUpdateHandler(w http.ResponseWriter, r *http.Request) {
	token, err := rtoken.CSRFToken(ach.csrfSignKey)
	if err != nil {
		http.Error(w, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
	}
	if r.Method == http.MethodGet {
		idRaw := r.URL.Query().Get("id")
		id, err := strconv.Atoi(idRaw)

		if err != nil {
			panic(err)
		}

		parms, _ := laborData.GetLaboratorist(uint(id))

		upPatient := struct {
			CSRF string
			Diag entity.Laboratorist
		}{
			CSRF: token,
			Diag: *parms,
		}

		ach.tmpl.ExecuteTemplate(w, "labor.prof.update.layout", upPatient)

	} else if r.Method == http.MethodPost {
		id, _ := strconv.Atoi(r.FormValue("id"))

		laboratorist, _ := laborData.GetLaboratorist(uint(id))
		fmt.Println("Laboratorist to be updated", laboratorist)
		pharms := entity.Laboratorist{}

		pharms.ID = laboratorist.ID
		// pharms.Uuid = laboratorist.Uuid
		pharms.Diagnosis = laboratorist.Diagnosis
		pharms.Uuid = laboratorist.Uuid

		//	pharms.User.Role = laboratorist.User.Role
		//pharmacist / profile
		//stt, _ := strconv.ParseUint(r.FormValue("id"), 10, 64)
		pharms.User.ID = laboratorist.User.ID
		pharms.User.FullName = r.FormValue("fullname")
		pharms.User.Phone = r.FormValue("phone")
		pharms.User.Address = r.FormValue("address")
		pharms.User.Password = laboratorist.User.Password
		if r.FormValue("image") == "" {
			pharms.User.Image = r.FormValue("image2")
		} else {
			pharms.User.Image = r.FormValue("image")

		}
		pharms.User.Sex = r.FormValue("sex")
		pharms.User.Email = r.FormValue("email")
		pharms.User.BirthDate = time.Now()
		pharms.User.RoleId = laboratorist.User.RoleId
		fmt.Println(r.FormValue("birthdate"))
		pharms.User.Description = r.FormValue("description")
		fmt.Println("updated profile", pharms)
		laborData.PutLaboratorist(&pharms)

		http.Redirect(w, r, "/laboratorist/profile", http.StatusSeeOther)

	} else {
		http.Redirect(w, r, "/laboratorist/profile", http.StatusSeeOther)
	}
}

func (ach *LaborProfHandler) LaborDiagnosisUpdateHandler(w http.ResponseWriter, r *http.Request) {
	token, err := rtoken.CSRFToken(ach.csrfSignKey)
	if err != nil {
		http.Error(w, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
	}
	if r.Method == http.MethodGet {
		idRaw := r.URL.Query().Get("id")
		id, err := strconv.Atoi(idRaw)

		if err != nil {
			panic(err)
		}
		parms, _ := laborData.GetDiagnosis(uint(id))
		log.Println("laboratorist", parms)
		upPatient := struct {
			CSRF string
			Diag entity.Diagnosis
		}{
			CSRF: token,
			Diag: *parms,
		}
		ach.tmpl.ExecuteTemplate(w, "labor.diag.update.layout", upPatient)

	} else if r.Method == http.MethodPost {
		id, _ := strconv.Atoi(r.FormValue("id"))
		laboratorist, _ := laborData.GetLaboratorist(ach.UserHandler.LoggedInUser.ID)
		diagns, _ := laborData.GetDiagnosis(uint(id))

		pharms := entity.Diagnosis{}

		pharms.ID = diagns.ID

		pharms.PatientName = diagns.PatientName
		pharms.PatientId = diagns.PatientId
		pharms.DoctorId = diagns.DoctorId
		pharms.LaboratoristId = laboratorist.ID
		pharms.DiagonosesDate = time.Now()
		pharms.Description = r.FormValue("description")
		pharms.Reponse = r.FormValue("response")
		pharms.ResponseDate = time.Now()
		laborData.PutDiagnosis(&pharms)

		http.Redirect(w, r, "/laboratorist/diagnosis", http.StatusSeeOther)

	} else {
		http.Redirect(w, r, "/laboratorist/diagnosis", http.StatusSeeOther)
	}
}
