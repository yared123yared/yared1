package Pharmacist_handler

import (
	"fmt"
	"net/http"
	"net/url"
	"strconv"
	"time"

	"github.com/web1_group_project/hospital_client/entity"
	"github.com/web1_group_project/hospital_client/form"
	"github.com/web1_group_project/hospital_client/rtoken"

	//"github.com/web1_group_project/hospital_client/session"
	pharmacistData "github.com/web1_group_project/hospital_client/data/pharmacist"
)

type PharmacsitForm struct {
	Values  url.Values
	VErrors form.ValidationErrors
	CSRF    string
}

func (ach *PharmProfHandler) ProHandler(w http.ResponseWriter, r *http.Request) {

	phamacist, _ := pharmacistData.GetPharmacist(ach.UserHandler.LoggedInUser.ID)
	ach.tmpl.ExecuteTemplate(w, "pharm.prof.layout", phamacist)

}

// PharmProfile handle requests on route /admin
func (ach *PharmProfHandler) PharmProfileUpdate(w http.ResponseWriter, r *http.Request) {
	// fmt.Println("thise is the petient calsspatient/profile/updatessssssssssssssssssssssssssssssssssssssssssssssssssssss")
	// token, err := rtoken.CSRFToken(ach.csrfSignKey)
	// if err != nil {
	// 	http.Error(w, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
	// }
	// if r.Method == http.MethodGet {
	// 	patient := *ach.LogedInPharmacist
	// 	values := url.Values{}
	// 	values.Add("fullname", patient.User.FullName)
	// 	values.Add("email", patient.User.Email)
	// 	values.Add("phone", patient.User.Phone)
	// 	values.Add("image", patient.User.Image)
	// 	values.Add("password", patient.User.Password)
	// 	values.Add("sex", patient.User.Sex)
	// 	upPatient := struct {
	// 		CSRF    string
	// 		Values  url.Values
	// 		VErrors form.ValidationErrors
	// 		Pharm   entity.Pharmacist
	// 	}{
	// 		CSRF:    token,
	// 		Values:  values,
	// 		VErrors: form.ValidationErrors{},
	// 		Pharm:   patient,
	// 	}
	// 	err = ach.tmpl.ExecuteTemplate(w, "pharm_prof.layout", upPatient)
	// 	return
	// }
	// if r.Method == http.MethodPost {
	// 	fmt.Println("patient update method")
	// 	// Parse the form data
	// 	err := r.ParseForm()
	// 	if err != nil {
	// 		http.Error(w, http.StatusText(http.StatusBadRequest), http.StatusBadRequest)
	// 		return
	// 	}
	// 	// Validate the form contents
	// 	updatePatientForm := form.Input{Values: r.PostForm, VErrors: form.ValidationErrors{}}
	// 	updatePatientForm.Required("fullname", "email", "phone", "description", "image")
	// 	updatePatientForm.MinLength("description", 10)
	// 	updatePatientForm.MatchesPattern("email", form.EmailRX)
	// 	updatePatientForm.MatchesPattern("phone", form.PhoneRX)
	// 	// updatePatientForm.MatchesPattern("full_name",form.NameRX)
	// 	// updatePatientForm.MatchesPattern("address",form.AddressRX)
	// 	updatePatientForm.CSRF = token
	// 	// If there are any errors, redisplay the signup form.
	// 	fmt.Println(updatePatientForm.Values)
	// 	fmt.Println(updatePatientForm.VErrors)

	// 	if !updatePatientForm.Valid() {
	// 		ach.tmpl.ExecuteTemplate(w, "pharm_prof.layout", updatePatientForm)
	// 		return
	// 	}
	// 	petient := *ach.LogedInPharmacist

	// 	user := &petient

	// 	fmt.Println(user.ID, user.User.FullName, "post")
	// 	user.User.FullName = r.FormValue("fullname")
	// 	user.User.Address = r.FormValue("address")
	// 	user.User.Email = r.FormValue("email")
	// 	user.User.Phone = r.FormValue("phone")
	// 	user.User.Address = r.FormValue("address")
	// 	user.User.BirthDate, _ = time.Parse(time.RFC3339, r.FormValue("birth_date"))
	// 	user.User.Image = r.FormValue("image")
	// 	user.User.Description = r.FormValue("description")
	// 	mf, fh, err := r.FormFile("image")
	// 	if err == nil {
	// 		user.User.Image = fh.Filename
	// 		pharmacistData.WriteFile(&mf, user.User.Image)
	// 	}
	// 	if mf != nil {
	// 		defer mf.Close()
	// 	}
	// 	pharmacistData.PutPharmacist(user)
	// 	*ach.LogedInPharmacist = *user
	// 	http.Redirect(w, r, "/pharmacist/profile", http.StatusSeeOther)
	// 	return
	// }
	token, err := rtoken.CSRFToken(ach.csrfSignKey)
	if err != nil {
		http.Error(w, http.StatusText(http.StatusInternalServerError), http.StatusInternalServerError)
	}
	if r.Method == http.MethodGet {
		patient := *ach.LogedInPharmacist
		values := url.Values{}
		values.Add("fullname", patient.User.FullName)
		values.Add("email", patient.User.Email)
		values.Add("phone", patient.User.Phone)
		values.Add("image", patient.User.Image)
		values.Add("password", patient.User.Password)
		values.Add("sex", patient.User.Sex)

		idRaw := r.URL.Query().Get("id")
		id, err := strconv.Atoi(idRaw)
		fmt.Println("Updated  Id ", id)

		if err != nil {
			panic(err)
		}
		parms, _ := pharmacistData.GetPharmacist(uint(id))
		fmt.Println("", parms)
		pharmacistAddForm := struct {
			Values  url.Values
			VErrors form.ValidationErrors
			CSRF    string
			Pharm   *entity.Pharmacist
		}{
			Values:  nil,
			VErrors: nil,
			CSRF:    token,
			Pharm:   parms,
		}

		ach.tmpl.ExecuteTemplate(w, "pharm_prof.layout", pharmacistAddForm)

	} else if r.Method == http.MethodPost {
		// if err != nil {
		// 	http.Error(w, http.StatusText(http.StatusBadRequest), http.StatusBadRequest)
		// 	return
		// }
		// // Validate the form contents
		// updatePatientForm := form.Input{Values: r.PostForm, VErrors: form.ValidationErrors{}}
		// updatePatientForm.Required("fullname", "email", "phone", "description", "image", "birth_date")
		// updatePatientForm.MinLength("description", 10)
		// updatePatientForm.MatchesPattern("email", form.EmailRX)
		// updatePatientForm.MatchesPattern("phone", form.PhoneRX)
		// // updatePatientForm.MatchesPattern("full_name",form.NameRX)
		// // updatePatientForm.MatchesPattern("address",form.AddressRX)
		// updatePatientForm.CSRF = token
		// // If there are any errors, redisplay the signup form.
		// fmt.Println(updatePatientForm.Values)
		// fmt.Println(updatePatientForm.VErrors)

		// if !updatePatientForm.Valid() {
		// 	ach.tmpl.ExecuteTemplate(w, "pharm_prof.layout", updatePatientForm)
		// 	return
		// }
		id, _ := strconv.Atoi(r.FormValue("id"))
		fmt.Println("form id is ", id)

		pharmacist, _ := pharmacistData.GetPharmacist(uint(id))
		fmt.Println(pharmacist.ID)

		pharms := entity.Pharmacist{}

		pharms.ID = pharmacist.ID
		pharms.Uuid = pharmacist.Uuid
		pharms.Medicine = pharmacist.Medicine
		pharms.Prescription = pharmacist.Prescription
		pharms.User.RoleId = pharmacist.User.RoleId

		stt, _ := strconv.ParseUint(r.FormValue("id"), 10, 64)
		pharms.User.ID = uint(stt)
		pharms.User.FullName = r.FormValue("fullname")
		pharms.User.Phone = r.FormValue("phone")
		pharms.User.Address = r.FormValue("address")
		if r.FormValue("image") == "" {
			pharms.User.Image = r.FormValue("image2")
		} else {
			pharms.User.Image = r.FormValue("image")

		}
		pharms.User.Sex = r.FormValue("sex")
		pharms.User.Email = r.FormValue("email")
		pharms.User.BirthDate = time.Now()
		fmt.Println(r.FormValue("birthdate"))
		pharms.User.Description = r.FormValue("description")
		fmt.Println("")
		pharmacistData.PutPharmacist(&pharms)

		http.Redirect(w, r, "/pharmacist/profile", http.StatusSeeOther)

	} else {
		http.Redirect(w, r, "/pharmacist/profile", http.StatusSeeOther)
	}

}
