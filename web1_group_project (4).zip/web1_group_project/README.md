                  Hospital Management system 
First there will be the following users to the system.
    1. Admin
    2. Doctorrr
    3. Laboratories
    4. Pharmacist
    5. Registrar
    6. patients
So our system will do the following functionalities
    1. Admin 
    • Hire doctors, registrar, pharmacist,laboratorist to the hospital so he/she will register them to the system.
    • When registering doctors to the system the admin should specify their area of specialization so the patients can easily select what they want from that system.
    • Can also remove the above users 
    2. Registrar
    • Can register patients for the first time.
    • When registering patients for the first time the patients have to be existed physically. The system will give them user name and password.
    • The system will ask them the following information’s
        ◦ Full name
        ◦ Age
        ◦ Place of residence 
        ◦ Phone number
        ◦ Email/if they have
    3. Patients
    • Can look who have been assigned for different categories like(eye,kideney,bone and different specialization)
    • Can request to examine for the doctor they want by specifying in the system.
    • The will get a notification for the order they have got when they are requesting for examining by the doctor . so they will get to the hospital by the time they have been reminded till then they can do other tasks.
    • They can see their cases online through the system they can see what medicine have they given by the pharmacist and everything in the system.
    • They can report complain to the admin directly for any in appropriate work.
    • They can leave the system this means they have been delated from the membership of that hospital.
    4. Doctors
    • Doctors can see the patients who have been requested to be examined by him/her.
    • can order medicine online through the system to the pharmacist to there will not be any paper work.
    • Can also order any lab examination to the laboratories online through the system.
    5. Pharmacist.
    • Will control whether the specified patient have taken the required medicine or not
        ◦ If the user come and take the medicine that the doctor have ordered then he will put taken mark.
    • Can see who take what medicine 
    6. Laboratories
    • Will control whether the specified patient have taken the required lab examination or not.
        ◦ If he/she take he will put taken mark other with not
    • Can see who take what lab examination


This is what I thought about it so try to read it well and modify it.

